# RPAM Plan Services React UI

Project is structured as follows:

```shell
├── app-settings 		# Application settings		
	├──	deploy   	# deployment scripts, templates, and values
	     
├── src          		# Place your application source code here (e.g. microservice, etc)
├── buildspec.yml      		# CodeBuild buildspec
├── Dockerfile        		# Dockerfile
```



## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

What things you need to install the software and how to install them

```
Install them from Software center or go to http://cgappstore/

From Internet, you would need to have admin privileges

1. GIT 
   a. Install Git on Windows- https://git-scm.com/download/win
   b. Install Git on Ubuntu- https://help.ubuntu.com/lts/serverguide/git.html#git-installation
   c. Install Git on Mac- https://git-scm.com/download/mac

2. Node.js
  Donwload Link- https://nodejs.org/en/download/

```

### Installing

A step by step series of commands that tells you how to get a development env running

1. Clone Repository

```
git clone repository name
```

2. Create Branch locally in your system by the below command

```
git checkout -b <branch-name>
```

3. To Push the local branch code changes,use the below command

```
git push -u origin <branch-name>
```

### Install MOCHA CHAI Testing Famework

A step by step series of commands that tells you how to install MOCHA and CHAI

```
1.$ npm install mocha chai nock --save-dev
```
```
2. Add the following code in your package.json file under scripts.
  "scripts": {
    "start": "node app",
    "servermon": "nodemon app",
    "test": "mocha || true"
  },
```
```
3. $ npm test on root folder command prompt/terminal
```

### Install log4j Logging Framework
A step by step series of commands that tells you how to install log4j

```
1. $ npm install --save log4js 
```
```
2. Add log4js-config.json file in you root folder.This file will contain all the logging related information for the project.
```

### Install express-validator
A step by step series of commands that tells you how to install express-validator

```
1. $ npm install --save express-validator
```

### Install nyc instanbul
A step by step series of commands that tells you how to install nyc instanbul

```
1. $ npm install --save-dev nyc
```

## Running the test cases

    $ npm test

## Running the project

    $ npm start

## Simple build for production

    $ npm build
<!-- 4. To copy the structure of the data base,use the below command

```
Command-
``` -->

<!-- End with an example of getting some data out of the system or using it for a little demo -->

<!-- ## Running the tests

Explain how to run the automated tests for this system

### Break down into end to end tests

Explain what these tests test and why

```
Give an example
```

### And coding style tests

Explain what these tests test and why

```
Give an example
``` -->

## Deployment

1. Create software package.
2. Upload the package on cloud server using File Transfer Protocol(FTP)
3. Run the script which stops the server,deploy the package and restarts the server.

<!-- ## Built With

* [Dropwizard](http://www.dropwizard.io/1.0.2/docs/) - The web framework used
* [Maven](https://maven.apache.org/) - Dependency Management
* [ROME](https://rometools.github.io/rome/) - Used to generate RSS Feeds -->

## Contributing

Please read the installing steps for contributing in the project.

<!-- ## Versioning

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/your/project/tags).  -->

<!-- ## Authors

* **Billie Thompson** - *Initial work* - [PurpleBooth](https://github.com/PurpleBooth)

See also the list of [contributors](https://github.com/your/project/contributors) who participated in this project. -->

## License

<!-- This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details -->

<!-- ## Acknowledgments

* Hat tip to anyone whose code was used
* Inspiration
* etc -->

## Setup
https://confluence.capgroup.com/pages/viewpage.action?pageId=306151463

## Sonar Qube 
C:\development\sonarqube-8.4.1.35646\sonarqube-8.4.1.35646\bin\windows-x86-64

cd conf
Run "StartSonar"
cd C:\development\RPAM\repo\develop\rpam
npm run sonar