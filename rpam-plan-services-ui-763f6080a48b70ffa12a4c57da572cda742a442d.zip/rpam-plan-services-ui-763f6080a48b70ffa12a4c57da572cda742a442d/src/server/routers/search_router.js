'use strict';
const express = require('express');
const SearchController = require('../controllers/search_controller').SearchController;
const URL_ROUTES = require('../commons/routes');

class SearchRouter {

  constructor() {
    this.routes = express.Router();
    const searchController = new SearchController();
    const ctrl = c => searchController[c].bind(searchController)();
    this.routes.get(URL_ROUTES.SEARCH, ctrl('search'));
    this.routes.get(URL_ROUTES.RECENT_SEARCHES, ctrl('recent_searches'));
    this.routes.get(URL_ROUTES.ASSOCIATES, ctrl('associates'));
    this.routes.get(URL_ROUTES.FREQUENT_SEARCHES, ctrl('frequent_searches'));
    this.routes.get(URL_ROUTES.PLANS, ctrl('plans'));
  }
  getRoutes() {
    return this.routes;
  }

}
exports.SearchRouter = SearchRouter;
