const ROUTES = {
    LOGIN:'/',
    NEW_USER:'/newUser',
    SEARCH:'/search',
    RECENT_SEARCHES:'/recent_searches',
    ASSOCIATES:'/associates',
    FREQUENT_SEARCHES:'/frequent_searches',
    PLANS:'/plans'
}

module.exports = ROUTES