const nock = require('nock');
let chai = require('chai');
const expect = chai.expect;

let config = require('../../config/config')
let env = process.env.NODE_ENV ? process.env.NODE_ENV : '';
let activeEnv = config(env);

const request = require('supertest');
let server_url = activeEnv.urls.JAVA_URL + ':' + activeEnv.server.JAVA_PORT;
const SearchRouter = require('../../routers/search_router').SearchRouter;
let routerApp = require('../../routers/search_router').SearchRouter;
const SearchController = require('../../controllers/search_controller').SearchController;
const searchController = new SearchController();
const ctrl = c => searchController[c].bind(searchController)();
const express = require('express');
const app = express();
// Mock Data
const search = require('../../fs/search-table.json');
const recentSearches = require('../../fs/recent-searches.json');
const associates = require('../../fs/associates.json');
const frequentSearches = require('../../fs/frequent_searches.json');
const plans = require('../../fs/plans.json');
res={};
describe('GET Search Results', () => {

    before(function(){
        app.use('/api',new SearchRouter().getRoutes());
    });
  
    it('Should return search results', () => {
    nock(server_url).get('/search-api-here').reply(200,search);
    return request(app)
            .get('/api/search')
            .then(function(res){
             expect(res.status).equals(200);
            });
    });

    // On error
    it('Should try to return search results and handle failures', () => {
      nock(server_url).get('/search-api-here').replyWithError(500,'Failed');;
      return request(app)
              .get('/api/search')
              .then(function(res){
               expect(res.status).equals(500);
              });
    });
  
    it('Should return Associates', () => {
      nock(server_url).get('/associates-api-here').reply(200,associates);
      return request(app)
              .get('/api/associates')
              .then(function(res){
               expect(res.status).equals(200);
              });
    });

    // On error
    it('Should try to return Associates and handle failures', () => {
      nock(server_url).get('/associates-api-here').replyWithError(500,'Failed');;
      return request(app)
              .get('/api/associates')
              .then(function(res){
               expect(res.status).equals(500);
              });
    });

    it("Should return Frequent Searches", function () {
      nock(server_url).get('/frequent_searches-api-here').reply(200,frequentSearches);
      return request(app)
              .get('/api/frequent_searches')
              .then(function(res){
                expect(res.status).equals(200);
              });
    })

    // On error
    it("Should try to return Frequent Searches and handle failures", function () {
      nock(server_url).get('/frequent_searches-api-here').replyWithError(500,'Failed');;
      return request(app)
              .get('/api/frequent_searches')
              .then(function(res){
                expect(res.status).equals(500);
              });
    })

    it("Should return Recent Searches", function () {
      nock(server_url).get('/recent_searches-api-here').reply(200,recentSearches);
      return request(app)
              .get('/api/recent_searches')
              .then(function(res){
                expect(res.status).equals(200);
              });
    })

    // On error
    it("Should try to return Recent Searches and handle failures", function () {
      nock(server_url).get('/recent_searches-api-here').replyWithError(500,'Failed');;
      return request(app)
              .get('/api/recent_searches')
              .then(function(res){
                expect(res.status).equals(500);
              });
    })

    it("Should return Plans", function () {
      nock(server_url).get('/plans-api').reply(200,plans);
      return request(app)
              .get('/api/plans')
              .then(function(res){
                expect(res.status).equals(200);
              });
    })

    // On error
    it("Should try to return Plans and handle failures", function () {
      nock(server_url).get('/plans-api').replyWithError(500,'Failed');;
      return request(app)
              .get('/api/plans')
              .then(function(res){
                expect(res.status).equals(500);
              });
    })
});

 

