const { query, body, validationResult} = require('express-validator');

const errorFormatter= (error)=> {
  if (error.nestedErrors !== undefined && error.nestedErrors !== null) {
    return `${error.nestedErrors[0].param} in ${error.nestedErrors[0].location}: ${error.nestedErrors[0].msg}`;
  }
  return `${error.param} in ${error.location}: ${error.msg}`;
}

const errorMessage =(validationObj)=> {
  return validationObj.array().map(errorFormatter).join('\n');
}

exports.validationHandler=(req, res, next)=> {
  const validationErrors = validationResult(req);
  if (!validationErrors.isEmpty()) {
    const errMsg = errorMessage(validationErrors);
    logger.warn(errMsg);
    res.status(400).send({
      "status": 400,
      "statusText": "Failed",
      "message": errMsg,
    });
    // res.status(400).send(errMsg);
  } else {
    next();
  }
}
