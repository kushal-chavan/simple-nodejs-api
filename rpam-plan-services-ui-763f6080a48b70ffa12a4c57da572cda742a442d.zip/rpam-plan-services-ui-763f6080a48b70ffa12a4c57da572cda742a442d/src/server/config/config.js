module.exports = function(){
    switch(process.env.NODE_ENV){
        case 'production':
            return {
                server: {
                    JAVA_PORT: 3005,
                    rootContext:'',
                    logPath: ''
                },
                //TODO - application,okta,
                urls: {
                    JAVA_URL: '',
                },
            };
        case 'qa':
            return {
                server: {
                    JAVA_PORT: 3007,
                    rootContext: '',
                    logPath: ''
                },
                 //TODO - application,okta,
                urls: {
                    JAVA_URL: '',
                },
            };

        case 'development':
            return {
                server: {
                    JAVA_PORT: 3006,
                    rootContext: '',
                    logPath: ''
                },
                 //TODO - application,okta,
                urls: {
                    JAVA_URL: '',
                },
            };
        default:
            return {
                server: {
                    JAVA_PORT: 4444,
                    rootContext: '',
                    logPath: ''
                },
                 //TODO - application,okta,
                urls: {
                    JAVA_URL: 'http://localhost',
                },
            };
    }
};