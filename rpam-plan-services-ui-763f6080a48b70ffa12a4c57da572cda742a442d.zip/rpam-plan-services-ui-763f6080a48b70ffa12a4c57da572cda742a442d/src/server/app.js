'use strict';
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const http=require('http');
const fs = require('fs');
const path = require('path');
const log4js = require('log4js');
const cors = require('cors');
const Config = require('./config/config');
const config = new Config();

const searchRouter=require('./routers/search_router').SearchRouter;
const port = process.env.PORT || 7070;
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
const logDirectory = path.join(__dirname, 'log');
fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory);

//logging configuration
log4js.configure(__dirname + '/log4js-config.json', {reloadSecs: 60, cwd: logDirectory});
var logger = log4js.getLogger('server'),
    clientLogger = log4js.getLogger('client'),
    httpLogger = log4js.getLogger('http');

logger.info('Starting the CG server');

app.use(log4js.connectLogger(httpLogger, { level: 'auto' }));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use('/api',new searchRouter().getRoutes());

app.use('/',(req,res,next)=>{
    logger.info("middleware started");
});

/*app.use(function(req, res, next){//NOSONAR
    res.header("Access-Control-Allow-Origin", "http://localhost:3002");//NOSONAR
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");//NOSONAR
    next(); //NOSONAR
});//NOSONAR*/

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

const server=http.createServer(app);
server.listen(port);
