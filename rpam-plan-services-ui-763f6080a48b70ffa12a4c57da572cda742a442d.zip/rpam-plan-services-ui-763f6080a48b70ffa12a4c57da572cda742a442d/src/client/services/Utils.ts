//import * as moment from "moment";

export function isDefaultTime(date: string): boolean {
  return date === "0001-01-01T00:00:00";
}

export type Order = "asc" | "desc";
export const ascendingOrder: Order = "asc";
export const descendingOrder: Order = "desc";

function desc<T>(a: any, b: any, orderBy: keyof T) {
  if (orderBy == 'planId' || orderBy == 'planName') {
    if (b.indexedBy.planIdNamePair[0][orderBy] < a.indexedBy.planIdNamePair[0][orderBy]) {
      return -1;
    }
    if (b.indexedBy.planIdNamePair[0][orderBy] > a.indexedBy.planIdNamePair[0][orderBy]) {
      return 1;
    }
  } else {
    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
  }

  return 0;
}

export function stableSort<T>(array: T[], cmp: (a: T, b: T) => number): T[] {
  const stabilizedThis = array.map((el, index) => [el, index] as [T, number]);
  stabilizedThis.sort((a, b) => {
    const order = cmp(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map(el => el[0]);
}

export function getSorting<T>(order: string, orderBy: keyof T): (a: { [key in keyof T]: any }, b: { [key in keyof T]: any }) => number {
  return order === descendingOrder ? (a, b) => desc(a, b, orderBy) : (a, b) => -desc(a, b, orderBy);
}

export function isDesktop(): boolean {
  return window.screen.width > 768;
}

export function isTablet(): boolean {
  return window.screen.width <= 768 && window.screen.width > 375;
}

export function isMobile(): boolean {
  return window.screen.width <= 375;
}