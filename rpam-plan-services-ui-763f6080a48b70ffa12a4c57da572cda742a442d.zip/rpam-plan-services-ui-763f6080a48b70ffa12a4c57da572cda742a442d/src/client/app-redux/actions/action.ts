import axios from 'axios';
const URL = window.location.origin;

// Search List
export const getImagingInboxData = (param: any) => {
    const request = axios.get('http://localhost:7070/api/search')//, reqHeader)
        .then(response => response.data)
    return {
        type: 'GET_SEARCH_LIST',
        payload: request
    }
}

// Associate List
export const getAssociateList = (params: any) => {
    const reqHeader = {
        headers: {
            "Access-Control-Allow-Origin": "*"
        }
    }
    const config =
    {
        "cgInitials": "",
        "firstName": "",
        "lastName": "",
        "roleId": "Client Coordinator",
        "teamManagerId": ""

    };
    const request =
        axios.post('https://apigw.rpam.aws-dev.capgroup.com/dev/rps/plan-service/associates/v1/search', config)//, reqHeader)
            .then(response => response.data.searchResults)
    return {
        type: 'GET_ASSOCIATE_LIST',
        payload: request
    }
}

//Search API Placeholder
export const getSearchAPIList = (params: any) => {
    const config =
    {
        "search":
        {
            "SearchText": "mockdata-TIN1",
            "PlanName": "",
            "PlanId": ""
        }
    }
    const request =
        axios.post('https://apigw.rpam.aws-dev.capgroup.com/dev/rps/plan-service/plans/v1/search', config)
            .then(response => response.data)
    return {
        type: 'GET_SEARCH_LIST',
        payload: request
    }
}