const initalState = {
    list: []
};

export function handleEventReducer(state = initalState, action) {
    switch (action.type) {
        case "LOAD_LIST": {
            const stateObj = {
                list: action.data
            }
            return Object.assign({}, state, stateObj);
        }
        case "GET_SEARCH_LIST": {
            return { ...state, inboxList: action.payload }
        }
        case "GET_ASSOCIATE_LIST": {
            return { ...state, associateList: action.payload }
        }
        default:
            return state
    }
}