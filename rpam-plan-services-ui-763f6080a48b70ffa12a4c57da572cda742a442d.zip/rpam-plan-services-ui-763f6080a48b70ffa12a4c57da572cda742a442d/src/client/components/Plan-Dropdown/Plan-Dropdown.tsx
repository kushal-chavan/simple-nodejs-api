import React, { Component } from "react";
import Modal from "@material-ui/core/Modal";
import classNames from "classnames";
import "./Plan-Dropdown.scss";
import {
  Tab,
  Tabs,
  AppBar
} from '@material-ui/core';
import { isNull } from "util";

const options = [
  {
    name: 'All Plans'
  },
  {
    name: 'Installation Plans'
  },
  {
    name: 'Termination Plans'
  },
  {
    name: 'All Sources'
  }]
interface PopoverProps {
  openModal?: boolean;
  onBackdropClick?: any;
  close?: Function;
  onSelect: Function;
  selectedValue: any;
}

export default class PlanDropdown extends Component<PopoverProps> {
  state = {
    planType: [{
      name: 'All Plans'
    },
    {
      name: 'Installation Plans'
    },
    {
      name: 'Termination Plans'
    },
    {
      name: 'All Sources'
    }
    ]
  };
  handleClose() {
    this.props.close();
  }

  handleSelect(args: any) {
    console.log(args.name)
    this.props.onSelect(args.name);
  }

  render() {
    const { planType } = this.state;
    const { selectedValue } = this.props;
    return (
      <div className='plan-dropdown-container'>
        {planType.map((index) => (
          <div key={index.name} onClick={() => this.handleSelect(index)} className={classNames({
            "plan-type": true,
            "selected-type": selectedValue === index.name
          })}>{index.name}
          </div>
        ))}
        {/* <div className='plan-type'>All Plans
        </div>
        <div className='plan-type'>Installation Plans
        </div>
        <div className='plan-type'>Termination Plans
        </div>
        <div className='plan-type'>All Sources
        </div> */}
      </div>
    );
  }
}
