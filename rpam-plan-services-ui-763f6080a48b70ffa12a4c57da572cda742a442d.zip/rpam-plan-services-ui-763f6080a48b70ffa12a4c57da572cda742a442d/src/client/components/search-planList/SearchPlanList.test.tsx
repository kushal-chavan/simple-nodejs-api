import React from "react";
import { shallow, configure } from "enzyme";
import { DataGrid } from "client/models";
import SearchPlanList from "./SearchPlanList";
import Adapter from "enzyme-adapter-react-16";

import * as ReactDOM from "react-dom";
configure({ adapter: new Adapter() });

describe("SearchPlanList test", () => {
    beforeEach(() => {

    });
    it('renders header without crashing', () => {
        const div = document.createElement('div');
        ReactDOM.render(<SearchPlanList />, div);
    });
});