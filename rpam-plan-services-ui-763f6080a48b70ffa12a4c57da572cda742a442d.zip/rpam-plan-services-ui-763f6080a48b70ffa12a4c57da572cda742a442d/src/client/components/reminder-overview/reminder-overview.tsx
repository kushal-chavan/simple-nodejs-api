
import React from 'react';
import './reminder-overview.scss';
import { Table, TableBody, TableContainer, TableRow, TableCell, TableFooter, TablePagination, TableHead, Paper } from "@material-ui/core";
import { TablePaginationActions } from 'client/components';

const columns = [
    {
        id: 'name',
        label: 'Name',
        minWidth: 170,
        align: 'left',
        format: (value) => value.toLocaleString('en-US'),
    },
    {
        id: 'calories',
        label: 'Data',
        minWidth: 170,
        align: 'left'
    },
    {
        id: 'fat',
        label: 'S No',
        minWidth: 170,
        align: 'left'
    }
];

function createData(name, calories, fat) {
    return { name, calories, fat };
}

const rows = [
    createData('A&R Enterprises LLC 401k Plan', 305, 3.7),
    createData('Bank of Ohio county', 452, 25.0),
    createData('401K PLan and trust', 262, 16.0),
    createData('A&W Logging', 3596, 16.0),
    createData('Conger LP Gas 401K', 408, 3.2),
    createData('Conger', 237, 9.0),
    createData('LSD 405k Plan', 375, 0.0),
    createData('A&W Logging', 356, 16.0),
    createData('Conger LP Gas 401K', 408, 3.2),
    createData('A&R Enterprises LLC', 437, 18.0),
].sort((a, b) => (a.calories < b.calories ? -1 : 1));

export default class ReminderOverview extends React.Component {
    state = {
        page: 0,
        rowsPerPage: 5,
    };
    handleChangePage = (event, newPage) => {
        this.setState({ page: newPage })
    }

    handleChangeRowsPerPage = (event) => {
        this.setState({ page: 0, rowsPerPage: event.target.value })
    }
    render() {
        let { page, rowsPerPage } = this.state;
        const emptyRows = rowsPerPage - Math.min(rowsPerPage, rows.length - page * rowsPerPage);

        return (
            <div className="table-container">
                <TableContainer component={Paper}>
                    <Table aria-label="custom pagination table">
                        <TableHead className="table-head">
                            <TableRow>
                                {columns.map((column) => (
                                    <TableCell
                                        key={column.id}
                                        align={'left'}
                                        style={{ minWidth: column.minWidth }} >
                                        {column.label}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {(rowsPerPage > 0
                                ? rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                : rows
                            ).map((row) => (
                                <TableRow key={row.calories}>
                                    <TableCell key={row.calories} component="th" scope="row">
                                        {row.name}
                                    </TableCell>
                                    <TableCell style={{ width: 160 }} align="left">
                                        {row.calories}
                                    </TableCell>
                                    <TableCell style={{ width: 160 }} align="left">
                                        {row.fat}
                                    </TableCell>
                                </TableRow>
                            ))}

                            {emptyRows > 0 && (
                                <TableRow style={{ height: 53 * emptyRows }}>
                                    <TableCell colSpan={6} />
                                </TableRow>
                            )}
                        </TableBody>
                        <TableFooter>
                            <TableRow>
                                <TablePagination
                                    rowsPerPageOptions={[5, 10, 25, { label: 'All', value: -1 }]}
                                    colSpan={3}
                                    count={rows.length}
                                    rowsPerPage={this.state.rowsPerPage}
                                    page={this.state.page}
                                    SelectProps={{
                                        inputProps: { 'aria-label': 'rows per page' },
                                        native: true,
                                    }}
                                    onChangePage={this.handleChangePage}
                                    onChangeRowsPerPage={this.handleChangeRowsPerPage}
                                    ActionsComponent={TablePaginationActions}
                                />
                            </TableRow>
                        </TableFooter>
                    </Table>
                </TableContainer>
            </div>
        );
    }
}
