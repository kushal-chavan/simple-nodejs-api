import React, { Component } from "react";
import Modal from "@material-ui/core/Modal";
import "./Global-SearchBar.scss";
import classNames from "classnames";
import { isIE, isEdge } from "react-device-detect";
import { GlobalSearchBox } from "..";

interface PopoverProps {
  openModal?: boolean;
  onBackdropClick: any;
  anchorEl?: any;
  id: any;
  close?: Function;
}

export default class GlobalSearch extends Component<PopoverProps> {
  state = {
    value: 0,
    openSearch: false,
  };
  handleClose() {
    this.props.close();
  }
  handleKeyUp = (e) => {
    this.setState({ openSearch: true });
    console.log(e);
  }
  render() {
    const { openModal, onBackdropClick, id } = this.props;
    const { openSearch } = this.state;
    return (
      <Modal open={openModal}
        className='global-search-modal'
        disableBackdropClick={false}
        onBackdropClick={onBackdropClick}
        BackdropProps={{ style: { backgroundColor: 'transparent' } }}
      >
        <div className={classNames({
          "modal": true,
          "internet-explorer": isIE || isEdge
        })}>
          <div className="search-dropdown">
            <div className='flex-layout'>
              <input width="48" id="Search" name="Search" type="search"
                onFocus={e => this.handleKeyUp(e)}
                onKeyUp={e => this.handleKeyUp(e)}
                onBlur={() => { }}
                placeholder="Search all plans, sources or reminders">
              </input>
              <img className='cancel-search' onClick={onBackdropClick} style={{ float: 'right', }} src={require('client/assets/images/search-remove-24-px.svg')} />

            </div>

            {openSearch && <div id="searchContent" className="search-content">
              <GlobalSearchBox searchKey='' openSearch={openSearch} />
            </div>}
          </div>
        </div>
      </Modal>
    )
  }
}


