import React, { Component } from "react";
import Modal from "@material-ui/core/Modal";
import "./error-modal.scss";

interface ErrorModalProps {
  openModal: boolean;
  onBackdropClick: any;
}

export default class ErrorModal extends Component<ErrorModalProps> {

  render() {
    const { openModal, onBackdropClick } = this.props;
    return (
      <div className="progress-modal-container">
        <Modal
          open={openModal}
          disableBackdropClick={false}
          onBackdropClick={onBackdropClick}>
          <div className="modal">
            <div className="title bold">It’s not you, it’s us.</div>
            <div className="subtitle">
              We are experiencing an error at the moment. <br />
              Please try again later <br />
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}
