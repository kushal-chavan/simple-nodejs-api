import React from 'react';
import ErrorModal from './error-modal';
import { shallow, configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import * as ReactDOM from "react-dom";
//import { expect } from 'chai';

configure({ adapter: new Adapter() });

describe('components --> Error-Modal', () => {
  it('renders  without crashing', () => {
    const div = document.createElement('div');
    ReactDOM.render(<ErrorModal openModal={true} onBackdropClick={() => { }} />, div);
  });
  it('should have progress-modal-container', () => {
    const _wrapper = shallow(<ErrorModal openModal={true} onBackdropClick={() => { }} />)
    expect(_wrapper.find('.progress-modal-container')).toHaveLength(1)
  })
});
