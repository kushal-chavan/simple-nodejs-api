import React, { Component } from "react";
import "./SearchBox.scss";


interface SearchBoxProps {
  openSearch: boolean;
  searchKey?: any;
}

export default class SearchBox extends Component<SearchBoxProps> {
  state = {
    value: 0,
  };

  render() {
    const { openSearch, searchKey } = this.props;
    const { value } = this.state;
    if (searchKey == '') {
      return (
        <div className='recent-searches-box'>
          <div className='recent-search-header'>RECENT SEARCHES</div>
          <div className='recent-items'>
            <span className='recent-item'>ABC Company 401K Plan</span>
            <img style={{ float: 'right', height: '14px' }} src={require('client/assets/images/remove-24px.svg')} />
          </div>
          <div className='recent-items'>
            <span className='recent-item'>XYZ Company Terminated Plan</span>
            <img style={{ float: 'right', height: '14px' }} src={require('client/assets/images/remove-24px.png')} />
          </div>
          <div className='recent-items'>
            <span className='recent-item'>ABC Company 401K Plan</span>
            <img style={{ float: 'right', height: '14px' }} src={require('client/assets/images/remove-24px.png')} />
          </div>
          <div className='recent-items'>
            <span className='recent-item'>Tom Slower 401K Plan</span>
            <img style={{ float: 'right', height: '14px' }} src={require('client/assets/images/remove-24px.png')} />
          </div>
          <div className='view-all-footer'>View All</div>
        </div >
      );
    }
    return (
      <div className='search-box-container'>
      </div >

    );
  }
}
