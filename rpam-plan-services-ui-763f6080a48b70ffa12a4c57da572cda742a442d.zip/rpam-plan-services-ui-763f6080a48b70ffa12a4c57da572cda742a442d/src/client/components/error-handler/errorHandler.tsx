import React from "react";
import "./errorHandler.scss";
import Logging from "client/services/client-logging";

class ErrorHandler extends React.Component {
  state = {
    error: null,
    errorInfo: null
  };
  logging = new Logging();
  componentDidCatch(error: any, errorInfo: any) {
    this.setState({
      error: error,
      errorInfo: errorInfo
    });
  }

  render() {
    if (this.state.errorInfo) {
      this.logging.error('Error occured');

      return (
        <div>
          <h2>Something went wrong</h2>
          <details style={{ whiteSpace: 'pre-wrap' }}>
            {this.state.error && this.state.error.toString()}
            <br />
            {this.state.errorInfo.componentStack}
          </details>
        </div>
      );
    }
    // Render children if there's no error
    return this.props.children;
  }
}

export default ErrorHandler;

