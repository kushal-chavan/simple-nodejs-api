import React from 'react';
import SearchBox from './SearchBox';
import { shallow, configure, mount } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import * as ReactDOM from "react-dom";
//import { expect } from 'chai';

configure({ adapter: new Adapter() });

describe('components --> Searhbox', () => {
  let props;
  beforeEach(() => {
    props = {
      openSearch: true,
      searchKey: true,
    }
  });
  it('renders  without crashing', () => {
    const div = document.createElement('div');
    ReactDOM.render(<SearchBox openSearch={true} searchKey='' />, div);
  });
  it('renders  without crashing with searckey', () => {
    const div = document.createElement('div');
    ReactDOM.render(<SearchBox openSearch={true} searchKey='rr' />, div);
  });
  it("should equal false", () => {
    props.openSearch = false;
    const wrapper = shallow<SearchBox>(<SearchBox  {...props} />);
    expect(wrapper.instance().props.openSearch).toEqual(false);
  })
  it('calls render in searchbox', (done) => {
    const spy = jest.spyOn(SearchBox.prototype, 'render');
    const wrapper = mount(<SearchBox {...props} />);
    expect(spy).toHaveBeenCalled();
    spy.mockReset();
    spy.mockRestore();
    done();
  });
  it('Should contain scss class search-box-container', () => {
    const _wrapper = mount(<SearchBox searchKey='rr' {...props} />);
    expect(_wrapper.find('.search-box-container')).toHaveLength(1)
  })
});
