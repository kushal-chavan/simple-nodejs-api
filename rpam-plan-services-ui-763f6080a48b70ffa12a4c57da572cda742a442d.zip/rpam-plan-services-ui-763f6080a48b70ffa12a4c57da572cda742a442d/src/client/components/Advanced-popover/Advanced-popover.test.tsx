import React from 'react';
import Advancedpopover from './Advanced-popover';
import { shallow, configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import * as ReactDOM from "react-dom";
//import { expect } from 'chai';

configure({ adapter: new Adapter() });

describe('components --> Error-Modal', () => {
  it('renders  without crashing', () => {
    const div = document.createElement('div');
    ReactDOM.render(<Advancedpopover openModal={true} id={'id'} />, div);
  });
  it('should have progress-modal-container', () => {
    const _wrapper = shallow(<Advancedpopover openModal={true} id={'id'} />)
    expect(_wrapper.find('.advanced-popover-container')).toHaveLength(1)
  })
});
