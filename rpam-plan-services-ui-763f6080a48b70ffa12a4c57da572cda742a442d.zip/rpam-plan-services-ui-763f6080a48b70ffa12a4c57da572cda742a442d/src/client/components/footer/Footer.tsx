import React, { Component } from "react";
import "./Footer.scss";

export default class Footer extends Component {
  render() {
    return (
      <div className="footer-component">
        <div className="footer">
          <div className="footer-container">
            <div className="copyright">
              Copyright © 2020 Capital Group, All rights reserved.
          </div>
            <div>
              Software version 1.5.9
          </div>
          </div>
        </div>
      </div>
    );
  }
}


