import React from 'react';
import { Provider } from 'react-redux';
import HeaderCmp from './Header-component';
import { shallow, configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import configureStore from 'redux-mock-store';

import renderer from 'react-test-renderer';

configure({ adapter: new Adapter() });
const mockStore = configureStore([]);
describe('components --> header', () => {
  let store;
  let component;
  beforeEach(() => {
    store = mockStore({
      myState: 'sample text',
    });
    component = renderer.create(
      <Provider store={store}>
        <HeaderCmp />
      </Provider>
    );
  });
  // it.skip('renders header without crashing', () => {
  //   const div = document.createElement('div');
  //   ReactDOM.render(<Router>
  //     <HeaderCmp />
  //   </Router>, div);
  // });
  // it.skip('should have header', () => {
  //   const _wrapper = shallow(<Router>
  //     <HeaderCmp />
  //   </Router>)
  //   expect(_wrapper.find('.header-container')).toHaveLength(1)
  // })
  it('should render with given state from Redux store', () => {
    expect(component.toJSON()).toMatchSnapshot();
  });
});
