import React, { Component } from "react";
import './settings-dialog.scss';
import { isIE, isEdge } from "react-device-detect";
import classNames from "classnames";

import {
  Chip,
  Grid,
  Button,
  Modal,
  Divider
} from '@material-ui/core';

interface SettingsModalProps {
  openModal: boolean;
  onSave: Function;
  onCancel: Function;
  settings: any
}
interface SettingsModalState {
  selectedValue: any,
  chekbox: boolean,
  settingsData: any,
  prevSettings: any,
  selectedCols: number,
  openConfirmationModal: boolean,
}

class SettingsModal extends Component<SettingsModalProps, SettingsModalState> {
  constructor(props) {
    super(props);

    this.state = {
      selectedValue: null,
      chekbox: false,
      settingsData: this.props.settings,
      prevSettings: this.props.settings,
      selectedCols: 0,
      openConfirmationModal: false
    };
  }
  componentDidMount() {
    let { settings } = this.props;
    const selectedCols = Object.keys(settings).filter((item) => {
      return settings[item] === true
    }).length;
    this.setState({ selectedCols });
  }
  handleChange = (event, value) => {
    this.setState({ selectedValue: value })
  }
  handleWarningCancel = () => {
    this.setState({ openConfirmationModal: false });
    this.props.onCancel();
  }
  handleCancel = () => {
    this.setState({ openConfirmationModal: true });
  }

  toggleSetting = (prop: any) => {
    console.log(prop);
    const { settingsData } = this.state;
    settingsData[prop] = !settingsData[prop];
    const deleteIds = Object.keys(settingsData).filter((item) => {
      return settingsData[item] === true
    });
    console.log(deleteIds);
    if (deleteIds.length <= 11)
      this.setState({
        settingsData: settingsData, selectedCols: deleteIds.length
      });
  }
  handleSave = () => {
    this.props.onSave(this.state.settingsData);
  }
  url = (prop: any) => {
    const { settingsData } = this.state;
    return settingsData[prop] == true ? 'client'
      : 'clientsss';
  }
  icon = (prop: any) => {
    const { settingsData } = this.state;
    return settingsData[prop] == true ?
      <img style={{ float: 'right' }} src={require('client/assets/images/remove_circle-24px.svg')} />
      : <img style={{ float: 'right' }} src={require('client/assets/images/add_circle-24px.svg')} />;
  }
  render() {
    const { openModal } = this.props;
    const { openConfirmationModal, settingsData, selectedCols } = this.state;
    return (
      <div id="WorkItem-Modal" className="progress-modal-container">
        <Modal className='workitem-modal' open={openModal}
          BackdropProps={{ style: { backgroundColor: 'rgba(0,0,0,0.47)' } }}
        >
          <div className={classNames({
            "modal": true,
            "internet-explorer": isIE || isEdge
          })}>
            <div className="move-workitem flex-column">
              <span>Table Settings</span>
              <span onClick={this.handleCancel}>
                <img style={{ float: 'right', height: '19px' }} src={require('client/assets/images/remove-24px.svg')} />
              </span>
            </div>
            <div className="modal-text ">Edit search results view by ADD or REMOVE columns</div>
            <div className='scroller'>
              <div className='selector-column'>
                <span className='column-selector'>Select up to 11 columns</span>
                <span className='column-selector'>{selectedCols} selected</span>
              </div>
              <Divider />
              <div className='settings-list'>
                <div className='flex-column'>
                  <span className='bold-select' >Plan Name</span>
                  <span >
                    <img className='disabled-svg' style={{ float: 'right' }} src={require('client/assets/images/remove_circle-24px.svg')} />
                  </span>
                </div>
                <div className='flex-column'>
                  <span className='bold-select'>Plan ID</span>
                  <span>
                    <img className='disabled-svg' style={{ float: 'right' }} src={require('client/assets/images/remove_circle-24px.svg')} />
                  </span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.taxId
                  })}>Tax ID</span>
                  <span style={{ cursor: 'pointer' }} onClick={() => this.toggleSetting('taxId')}>{this.icon('taxId')}</span>
                  {/* <img style={{ float: 'right' }} src={require('client/assets/images/remove_circle-24px.svg')} /> */}
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.Notes
                  })}>Notes</span>
                  <span style={{ cursor: 'pointer' }} onClick={() => this.toggleSetting('Notes')}>{this.icon('Notes')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.city
                  })}>City</span>
                  <span style={{ cursor: 'pointer' }} onClick={() => this.toggleSetting('city')}>{this.icon('city')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.state
                  })}>State</span>
                  <span style={{ cursor: 'pointer' }} onClick={() => this.toggleSetting('state')}>{this.icon('state')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.planStatus
                  })}>Plan Status</span>
                  <span style={{ cursor: 'pointer' }} onClick={() => this.toggleSetting('planStatus')}>{this.icon('planStatus')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.shareClass
                  })}>Share Class</span>
                  <span style={{ cursor: 'pointer' }} onClick={() => this.toggleSetting('shareClass')}>{this.icon('shareClass')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.dealerName
                  })}>Dealer Name</span>
                  <span style={{ cursor: 'pointer' }} onClick={() => this.toggleSetting('dealerName')}>{this.icon('dealerName')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.TPAName
                  })}>TPA Name</span>
                  <span onClick={() => this.toggleSetting('TPAName')}>{this.icon('TPAName')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.tpaTaxID
                  })}>TPA Tax ID</span>
                  <span onClick={() => this.toggleSetting('tpaTaxID')}>{this.icon('tpaTaxID')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.tpaAddress
                  })}>TPA Address</span>
                  <span onClick={() => this.toggleSetting('tpaAddress')}>{this.icon('tpaAddress')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.tpaEmailAddress
                  })}>TPA Email Address</span>
                  <span onClick={() => this.toggleSetting('tpaEmailAddress')}>{this.icon('tpaEmailAddress')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.tpaPhNumber
                  })}>TPA Phone Number</span>
                  <span onClick={() => this.toggleSetting('tpaPhNumber')}>{this.icon('tpaPhNumber')}</span>
                </div>
                <div className='flex-column'>
                  <span className={classNames({
                    "bold-select": settingsData.dealerRepName
                  })}>Dealer Representative Name</span>
                  <span onClick={() => this.toggleSetting('dealerRepName')}>{this.icon('dealerRepName')}</span>
                </div>

              </div>
            </div>

            <Grid className='popup-button-footer'>
              {/* <Button id="cancelButton" className="cancel-btn" onClick={this.handleCancel}>
                Cancel </Button> */}
              <Button id="moveButton"
                className={classNames('move-btn', {
                  //  "move-enabled": selectedValue != null,
                })} onClick={this.handleSave}>
                Save</Button>
            </Grid>
          </div>
        </Modal>
        <Modal className='warning-modal'
          open={openConfirmationModal}
          BackdropProps={{ style: { backgroundColor: 'rgba(0,0,0,0.47)' } }}>
          <div className={classNames({
            "modal": true,
            "modal-warning": true,
            "internet-explorer": isIE || isEdge
          })}>
            <div className='warning-modal-text'>The changes you made won't be saved.</div>
            <div className='warning-modal-text'>Do you still want to exit ?</div>
            <Grid className='popup-button-footer'>
              <Button id="no-button" className="warning-btn" onClick={() => { this.setState({ openConfirmationModal: false }) }}>
                NO </Button>
              <Button id="yes-button"
                className={classNames('warning-btn', {
                  //  "move-enabled": selectedValue != null,
                })} onClick={this.handleWarningCancel}>
                YES</Button>
            </Grid>
          </div>
        </Modal>
      </div >
    );
  }
}

export default SettingsModal;