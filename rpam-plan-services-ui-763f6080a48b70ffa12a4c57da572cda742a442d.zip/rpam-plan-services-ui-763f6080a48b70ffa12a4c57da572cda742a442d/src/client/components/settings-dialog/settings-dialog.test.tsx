import React from 'react';
import SettingsModal from './settings-modal';
import { shallow, configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import * as ReactDOM from "react-dom";
//import { expect } from 'chai';

configure({ adapter: new Adapter() });

describe('components --> Error-Modal', () => {
  it('renders  without crashing', () => {
    const div = document.createElement('div');
    ReactDOM.render(<SettingsModal openModal={true} onCancel={() => { }}
      onChange={() => { }} />, div);
  });
  it('should have progress-modal-container', () => {
    const _wrapper = shallow(<SettingsModal openModal={true} onCancel={() => { }}
      onChange={() => { }} />)
    expect(_wrapper.find('.modal')).toHaveLength(1)
  })
});
