import React, { Component } from "react";

class Reports extends Component {
  render() {
    return (
    <div className="container">
      <div className="page-header">Reports Page</div>
    </div>
    );
  }
}

export default Reports;