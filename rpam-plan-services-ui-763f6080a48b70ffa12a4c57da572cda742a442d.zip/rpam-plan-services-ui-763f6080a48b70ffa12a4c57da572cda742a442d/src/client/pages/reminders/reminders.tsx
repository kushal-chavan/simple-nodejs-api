import React, { Component } from "react";

class Reminders extends Component {

  render() {
    return (
      <div className="container">
        <div className="page-header">Reminders Page
        </div>
      </div>
    );
  }
}

export default Reminders;