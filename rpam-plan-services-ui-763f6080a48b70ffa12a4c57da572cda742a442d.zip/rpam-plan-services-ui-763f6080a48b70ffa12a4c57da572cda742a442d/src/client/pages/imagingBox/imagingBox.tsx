import React, { Component } from "react";

class ImagingBox extends Component {
  render() {
    return (
    <div className="container">
      <div className="page-header">Imaging Box Page</div>
    </div>
    );
  }
}

export default ImagingBox;