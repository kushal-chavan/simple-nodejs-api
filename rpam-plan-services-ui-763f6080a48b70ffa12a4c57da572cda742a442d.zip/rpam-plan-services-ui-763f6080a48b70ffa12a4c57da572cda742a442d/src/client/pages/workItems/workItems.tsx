import React, { Component } from "react";

class WorkItems extends Component {
  render() {
    return (
      <div className="container">
        <div className="page-header">Work Items Page</div>
      </div>
    );
  }
}

export default WorkItems;