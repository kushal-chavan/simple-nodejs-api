import React, { Component } from "react";

class GetWork extends Component {
  render() {
    return (
      <div className="container">
        <div className="page-header">Get Works Page</div>
      </div>
    );
  }
}

export default GetWork;