import React from 'react';
import HeaderCmp from './homePage';
import { shallow, configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import * as ReactDOM from "react-dom";
//import { expect } from 'chai';

configure({ adapter: new Adapter() });

describe('components --> header', () => {
  it('renders header without crashing', () => {
    const div = document.createElement('div');
    ReactDOM.render(<HeaderCmp />, div);
  });
  it('should have HomeMenuTable', () => {
    const _wrapper = shallow(<HeaderCmp />)
    expect(_wrapper.find('.HomeMenuTable')).toHaveLength(1)
  })
});
