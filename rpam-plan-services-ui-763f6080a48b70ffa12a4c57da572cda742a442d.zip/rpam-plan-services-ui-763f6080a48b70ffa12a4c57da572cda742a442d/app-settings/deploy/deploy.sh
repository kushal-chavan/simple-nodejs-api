#!/bin/bash

# Get Environment
ENV=$1

# Substitute Environment Specific Values
echo "Deploying to ${ENV} environment"
. ./common_env.sh
. ./${ENV}_env.sh

envsubst < app_deploy.yml > "./app_deploy_env.yml"

# Run KUBECTL APPLY
echo "kubectl apply -f ./app_deploy_env.yml"
cat ./app_deploy_env.yml
kubectl apply -f ./app_deploy_env.yml