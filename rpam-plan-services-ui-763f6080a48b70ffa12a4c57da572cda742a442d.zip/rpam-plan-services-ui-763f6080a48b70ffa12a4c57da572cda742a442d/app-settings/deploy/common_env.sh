#!/bin/bash

# Export common env values to be substituted in Kube templates
export name="hello-k8s"
export image="cgdevregistry.capgroup.com/hello-k8s"
export serviceport="80"
export containerport="8080"
